import { createBrowserRouter, RouterProvider ,createRoutesFromElements, Route} from "react-router-dom";
import HomePage from "./pages/Home";
import ProductDetails from "./pages/ProductDetails";
import Products from "./pages/Products";
import RootLayout from "./pages/Root";

const router = createBrowserRouter([
  {
    path:'/',
    element:<RootLayout />,
    children:[
      {index: true, element: <HomePage />},
      {path:'products',element: <Products/>},
      {path:'products/:productId',element:<ProductDetails />}
     
    ]
  },
   ]);

  //alternative to above method

// const routeDefinitions=createRoutesFromElements(
//   <Route>
//     <Route path="/" element={<HomePage />} />
//     <Route path="/products" element={<Products />} />
//   </Route>
// )

// const router=createRoutesFromElements(routeDefinitions);

function App() {
  return <RouterProvider router={router}/>
} 

export default App;
