import { createBrowserRouter, RouterProvider ,createRoutesFromElements, Route} from "react-router-dom";
import HomePage from "./pages/Home";
import Products from "./pages/Products";
import RootLayout from "./pages/Root";

const router = createBrowserRouter([
  {
    path:'/',
    element:<RootLayout />,
    children:[
      { path:'/', element: <HomePage />},
      {path:'/products',element: <Products/>}
     
    ]
  },
   ]);

  //alternative to above method

// const routeDefinitions=createRoutesFromElements(
//   <Route>
//     <Route path="/" element={<HomePage />} />
//     <Route path="/products" element={<Products />} />
//   </Route>
// )

// const router=createRoutesFromElements(routeDefinitions);

function App() {
  return <RouterProvider router={router}/>
} 

export default App;
