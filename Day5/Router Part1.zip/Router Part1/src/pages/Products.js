export default function(){
    return <h1>Products Page</h1>
}